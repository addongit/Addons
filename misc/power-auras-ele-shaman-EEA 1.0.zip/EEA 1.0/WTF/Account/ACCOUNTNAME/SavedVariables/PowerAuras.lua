
PowaGlobalSet = {
}
PowaGlobalListe = {
	"Global 1", -- [1]
	"Global 2", -- [2]
	"Global 3", -- [3]
	"Global 4", -- [4]
	"Global 5", -- [5]
	"Global 6", -- [6]
	"Global 7", -- [7]
	"Global 8", -- [8]
	"Global 9", -- [9]
	"Global 10", -- [10]
}
