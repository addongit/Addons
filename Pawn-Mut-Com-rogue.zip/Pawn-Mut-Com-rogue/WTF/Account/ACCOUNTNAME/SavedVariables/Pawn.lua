
PawnCommon = {
	["ShownGettingStarted"] = true,
	["ShowEnchanted"] = false,
	["Digits"] = 1,
	["ShowSpace"] = true,
	["AlignNumbersRight"] = true,
	["ShowTooltipIcons"] = true,
	["Scales"] = {
		["\"Wowhead\":ShamanEnhancement"] = {
			["PerCharacterOptions"] = {
				["Nzeer-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							50.33139454369201, -- [1]
							55812, -- [2]
						},
						["INVTYPE_FEET"] = {
							38.00733970364215, -- [1]
							55584, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							93.43672834574372, -- [1]
							52493, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							125.0623778280981, -- [1]
							56116, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							37.69200941697826, -- [1]
							56518, -- [2]
						},
						["INVTYPE_LEGS"] = {
							65.74864977149979, -- [1]
							56513, -- [2]
						},
						["INVTYPE_FINGER"] = {
							32.84503531366847, -- [1]
							55859, -- [2]
							27.55490929234178, -- [3]
							62436, -- [4]
						},
						["INVTYPE_RELIC"] = {
							23.26935327516964, -- [1]
							62242, -- [2]
						},
						["INVTYPE_WRIST"] = {
							26.41476249826894, -- [1]
							55802, -- [2]
						},
						["INVTYPE_WAIST"] = {
							36.3187924110234, -- [1]
							62439, -- [2]
						},
						["INVTYPE_NECK"] = {
							35.3377648525135, -- [1]
							56110, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							40.22365323362415, -- [1]
							55621, -- [2]
						},
						["INVTYPE_HAND"] = {
							36.05428610995707, -- [1]
							63806, -- [2]
						},
						["INVTYPE_CHEST"] = {
							58.60005539398975, -- [1]
							56504, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["LocalizedName"] = "Shaman: enhancement",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "526fbf",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":DeathKnightUnholyDps"] = {
			["PerCharacterOptions"] = {
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "DK: unholy ",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf3950",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":DeathKnightFrostDps"] = {
			["PerCharacterOptions"] = {
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "DK: frost",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf3950",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":WarriorArms"] = {
			["PerCharacterOptions"] = {
				["Blendtech-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							79.67521506248986, -- [1]
							55229, -- [2]
						},
						["INVTYPE_FEET"] = {
							48.29410809933452, -- [1]
							49906, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							22.90439863658497, -- [1]
							55347, -- [2]
						},
						["INVTYPE_CHEST"] = {
							68.4492777146567, -- [1]
							55500, -- [2]
						},
						["INVTYPE_RANGED"] = {
							19.01477032949197, -- [1]
							55782, -- [2]
						},
						["INVTYPE_HAND"] = {
							45.53449115403343, -- [1]
							55026, -- [2]
						},
						["INVTYPE_FINGER"] = {
							39.04625872423308, -- [1]
							52310, -- [2]
							39.04625872423308, -- [3]
							52310, -- [4]
						},
						["INVTYPE_SHOULDER"] = {
							53.82080831033923, -- [1]
							50020, -- [2]
						},
						["INVTYPE_WRIST"] = {
							31.87599415679273, -- [1]
							55025, -- [2]
						},
						["INVTYPE_WAIST"] = {
							49.55494237948385, -- [1]
							55554, -- [2]
						},
						["INVTYPE_NECK"] = {
							38.45382243142347, -- [1]
							52312, -- [2]
						},
						["INVTYPE_LEGS"] = {
							76.32510956013634, -- [1]
							55260, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							32.64534978087973, -- [1]
							55311, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							23.01866580100633, -- [1]
							67029, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Warrior: arms",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "957552",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":WarlockDestruction"] = {
			["PerCharacterOptions"] = {
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Warlock: destruction",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "8d7bbf",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":PaladinTank"] = {
			["PerCharacterOptions"] = {
				["Brewn-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							182.7943925233645, -- [1]
							55039, -- [2]
						},
						["INVTYPE_FEET"] = {
							165.5233644859813, -- [1]
							56387, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							300.392523364486, -- [1]
							56402, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							29.67289719626168, -- [1]
							55367, -- [2]
						},
						["INVTYPE_WRIST"] = {
							69.61682242990655, -- [1]
							63865, -- [2]
						},
						["INVTYPE_LEGS"] = {
							136.6635514018692, -- [1]
							55038, -- [2]
						},
						["INVTYPE_FINGER"] = {
							85.04672897196262, -- [1]
							62427, -- [2]
							44.62616822429906, -- [3]
							55799, -- [4]
						},
						["INVTYPE_RELIC"] = {
							39.7196261682243, -- [1]
							63772, -- [2]
						},
						["INVTYPE_HAND"] = {
							95.12149532710281, -- [1]
							63859, -- [2]
						},
						["INVTYPE_WAIST"] = {
							127.5233644859813, -- [1]
							63805, -- [2]
						},
						["INVTYPE_NECK"] = {
							52.33644859813084, -- [1]
							55864, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							113.4766355140187, -- [1]
							66907, -- [2]
						},
						["INVTYPE_CHEST"] = {
							174.0467289719626, -- [1]
							63919, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							86.39252336448598, -- [1]
							62377, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["LocalizedName"] = "Paladin: tank",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "b7698b",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":HunterBeastMastery"] = {
			["PerCharacterOptions"] = {
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Hunter: beast mastery",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "809f56",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":PaladinHoly"] = {
			["PerCharacterOptions"] = {
				["Brewn-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							132.7854346123727, -- [1]
							55039, -- [2]
						},
						["INVTYPE_FEET"] = {
							115.984599321326, -- [1]
							56387, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							80.46254241712346, -- [1]
							56402, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							201.0146175933176, -- [1]
							55367, -- [2]
						},
						["INVTYPE_WRIST"] = {
							51.67710780475071, -- [1]
							63865, -- [2]
						},
						["INVTYPE_LEGS"] = {
							104.0910989297833, -- [1]
							55038, -- [2]
						},
						["INVTYPE_FINGER"] = {
							73.15374575828766, -- [1]
							62427, -- [2]
							51.17227877838684, -- [3]
							55799, -- [4]
						},
						["INVTYPE_RELIC"] = {
							39.75985382406682, -- [1]
							63772, -- [2]
						},
						["INVTYPE_HAND"] = {
							68.47820412424954, -- [1]
							63859, -- [2]
						},
						["INVTYPE_WAIST"] = {
							96.95066562255286, -- [1]
							63805, -- [2]
						},
						["INVTYPE_NECK"] = {
							60.09501435656487, -- [1]
							55864, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							82.25998433829287, -- [1]
							66907, -- [2]
						},
						["INVTYPE_CHEST"] = {
							130.1232054293918, -- [1]
							63919, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							76.53980683894544, -- [1]
							62377, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["LocalizedName"] = "Paladin: holy",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "b7698b",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":RogueCombat"] = {
			["PerCharacterOptions"] = {
				["Yiffylube-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONOFFHAND"] = {
							2.161038769955124, -- [1]
							44096, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							0.9715294636945486, -- [1]
							42952, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							2.465996153482359, -- [1]
							42945, -- [2]
						},
						["INVTYPE_CHEST"] = {
							1.126682851467667, -- [1]
							48689, -- [2]
						},
					},
				},
				["Slashwin-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONMAINHAND"] = {
							123.568699575762, -- [1]
							56127, -- [2]
						},
						["INVTYPE_HEAD"] = {
							124.7431030677555, -- [1]
							66936, -- [2]
						},
						["INVTYPE_FEET"] = {
							63.44625910395056, -- [1]
							66967, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							118.1937131506763, -- [1]
							66968, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							57.80269256234827, -- [1]
							56518, -- [2]
						},
						["INVTYPE_RANGED"] = {
							24.74442727874641, -- [1]
							61401, -- [2]
						},
						["INVTYPE_FINGER"] = {
							53.72919885235047, -- [1]
							52316, -- [2]
							51.51335246082542, -- [3]
							52316, -- [4]
						},
						["INVTYPE_LEGS"] = {
							109.6934451555948, -- [1]
							56513, -- [2]
						},
						["INVTYPE_HAND"] = {
							69.52637386890311, -- [1]
							56484, -- [2]
						},
						["INVTYPE_WAIST"] = {
							74.79099536526152, -- [1]
							56098, -- [2]
						},
						["INVTYPE_NECK"] = {
							45.63981461046127, -- [1]
							65811, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							61.21054954756124, -- [1]
							55693, -- [2]
						},
						["INVTYPE_WRIST"] = {
							51.4930478922975, -- [1]
							63898, -- [2]
						},
						["INVTYPE_CHEST"] = {
							87.2652836018539, -- [1]
							63866, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["LocalizedName"] = "Rogue: combat",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfb74e",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":PriestDiscipline"] = {
			["PerCharacterOptions"] = {
				["Zebsaru-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							120.8454896614406, -- [1]
							54485, -- [2]
						},
						["INVTYPE_FEET"] = {
							56.80731651897296, -- [1]
							54482, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							36.56987048398091, -- [1]
							65802, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							327.9929561463304, -- [1]
							55045, -- [2]
						},
						["INVTYPE_RANGED"] = {
							22.67961826857532, -- [1]
							67104, -- [2]
						},
						["INVTYPE_HAND"] = {
							66.17155192001818, -- [1]
							55737, -- [2]
						},
						["INVTYPE_FINGER"] = {
							58.21949556918882, -- [1]
							56220, -- [2]
							45.64439900022722, -- [3]
							66893, -- [4]
						},
						["INVTYPE_LEGS"] = {
							110.0070438536696, -- [1]
							56218, -- [2]
						},
						["INVTYPE_WRIST"] = {
							32.76618950238582, -- [1]
							55709, -- [2]
						},
						["INVTYPE_WAIST"] = {
							43.80345376050898, -- [1]
							55772, -- [2]
						},
						["INVTYPE_NECK"] = {
							64.6414451261077, -- [1]
							52314, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							67.81117927743695, -- [1]
							54479, -- [2]
						},
						["INVTYPE_CHEST"] = {
							85.91820040899795, -- [1]
							67106, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							48.90411270165871, -- [1]
							66889, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Priest: discipline",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfbfbf",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":WarlockAffliction"] = {
			["PerCharacterOptions"] = {
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Warlock: affliction",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "8d7bbf",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":MageFrost"] = {
			["PerCharacterOptions"] = {
				["Pantyraid-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							184.9663815983486, -- [1]
							57864, -- [2]
						},
						["INVTYPE_FEET"] = {
							82.33795340607489, -- [1]
							66937, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							73.82247124741963, -- [1]
							57923, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							223.3093482748452, -- [1]
							56116, -- [2]
						},
						["INVTYPE_RANGED"] = {
							21.48569743438513, -- [1]
							55823, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							58.48835151872603, -- [1]
							62377, -- [2]
						},
						["INVTYPE_FINGER"] = {
							69.21026245945149, -- [1]
							56432, -- [2]
							61.85019168386906, -- [3]
							55859, -- [4]
						},
						["INVTYPE_LEGS"] = {
							138.6593925095842, -- [1]
							56413, -- [2]
						},
						["INVTYPE_HAND"] = {
							103.8003538779121, -- [1]
							58158, -- [2]
						},
						["INVTYPE_WAIST"] = {
							82.71837216160424, -- [1]
							63921, -- [2]
						},
						["INVTYPE_NECK"] = {
							81.70215275729873, -- [1]
							52322, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							84.34915953995871, -- [1]
							66910, -- [2]
						},
						["INVTYPE_WRIST"] = {
							55.26835741669124, -- [1]
							63826, -- [2]
						},
						["INVTYPE_CHEST"] = {
							138.6593925095842, -- [1]
							62441, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Mage: frost",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "4e99b3",
			["SmartGemSocketing"] = true,
		},
		["(Ass) 85 PVE MH Mut MAEP"] = {
			["Values"] = {
				["SpeedBaseline"] = 1.8,
				["CritRating"] = 0.43,
				["Agility"] = 1,
				["ResilienceRating"] = 0.001,
				["MeleeMaxDamage"] = 0,
				["HasteRating"] = 0.46,
				["MasteryRating"] = 0.49,
				["YellowSocket"] = 29.8,
				["MeleeDps"] = 1.85,
				["ExpertiseRating"] = 0.42,
				["Strength"] = 0.42,
				["MetaSocket"] = 26.46,
				["RedSocket"] = 40,
				["BlueSocket"] = 30.6,
				["HitRating"] = 0.53,
				["MeleeSpeed"] = -50,
				["Stamina"] = 0.01,
				["MeleeMinDamage"] = 0,
				["Ap"] = 0.38,
			},
			["SmartGemSocketing"] = true,
			["PerCharacterOptions"] = {
				["Slashwin-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WRIST"] = {
							210.85, -- [1]
							63898, -- [2]
						},
						["INVTYPE_HEAD"] = {
							416.6999999999999, -- [1]
							66936, -- [2]
						},
						["INVTYPE_FEET"] = {
							283.05, -- [1]
							66967, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							821.0635714285717, -- [1]
							66968, -- [2]
						},
						["INVTYPE_CHEST"] = {
							379.63, -- [1]
							63866, -- [2]
						},
						["INVTYPE_RANGED"] = {
							106.97, -- [1]
							61401, -- [2]
						},
						["INVTYPE_FINGER"] = {
							230.55, -- [1]
							52316, -- [2]
							229.99, -- [3]
							52316, -- [4]
						},
						["INVTYPE_SHOULDER"] = {
							251.84, -- [1]
							55693, -- [2]
						},
						["INVTYPE_HAND"] = {
							282.04, -- [1]
							56484, -- [2]
						},
						["INVTYPE_WAIST"] = {
							325.65, -- [1]
							56098, -- [2]
						},
						["INVTYPE_NECK"] = {
							204.05, -- [1]
							65811, -- [2]
						},
						["INVTYPE_LEGS"] = {
							445.08, -- [1]
							56513, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							855.7588888888889, -- [1]
							56127, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							248.9, -- [1]
							56518, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f0ff00",
			["UnenchantedColor"] = "b3bf00",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
		},
		["Feral Druid Cat (Mew)"] = {
			["PerCharacterOptions"] = {
				["Ravenstride-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							75, -- [1]
							56505, -- [2]
						},
						["INVTYPE_FEET"] = {
							47.08333333333334, -- [1]
							55656, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							43.58333333333334, -- [1]
							56518, -- [2]
						},
						["INVTYPE_HAND"] = {
							51.66666666666666, -- [1]
							56484, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							52.66666666666666, -- [1]
							56495, -- [2]
						},
						["INVTYPE_2HWEAPON"] = {
							209.1904761904762, -- [1]
							55246, -- [2]
						},
						["INVTYPE_RELIC"] = {
							28, -- [1]
							62242, -- [2]
						},
						["INVTYPE_WRIST"] = {
							36.25, -- [1]
							65798, -- [2]
						},
						["INVTYPE_WAIST"] = {
							50.83333333333334, -- [1]
							65801, -- [2]
						},
						["INVTYPE_NECK"] = {
							35.33333333333334, -- [1]
							55833, -- [2]
						},
						["INVTYPE_LEGS"] = {
							96.41666666666667, -- [1]
							56513, -- [2]
						},
						["INVTYPE_FINGER"] = {
							46.41666666666666, -- [1]
							61474, -- [2]
							46.41666666666666, -- [3]
							61474, -- [4]
						},
						["INVTYPE_CHEST"] = {
							71.08333333333333, -- [1]
							55646, -- [2]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["Color"] = "00ffe3",
			["SmartMetaGemSocketing"] = true,
			["NormalizationFactor"] = 1,
			["MetaGemQualityLevel"] = 86,
			["UnenchantedColor"] = "00bfaa",
			["Values"] = {
				["Intellect"] = -1000000,
				["IsFist"] = -1000000,
				["IsMace"] = -1000000,
				["CritRating"] = 1,
				["IsWand"] = -1000000,
				["HasteRating"] = 0,
				["IsDagger"] = -1000000,
				["Agility"] = 3,
				["ExpertiseRating"] = 0,
				["MasteryRating"] = 1,
				["YellowSocket"] = 6.666666666666667,
				["IsCrossbow"] = -1000000,
				["MeleeDps"] = 4,
				["IsGun"] = -1000000,
				["IsThrown"] = -1000000,
				["RedSocket"] = 10,
				["Is2HAxe"] = -1000000,
				["IsShield"] = -1000000,
				["MetaSocket"] = 4.5,
				["IsBow"] = -1000000,
				["Strength"] = 2,
				["IsSword"] = -1000000,
				["IsMail"] = -1000000,
				["IsPlate"] = -1000000,
				["HitRating"] = 0,
				["BlueSocket"] = 5,
				["Is2HSword"] = -1000000,
				["SpellPower"] = -1000000,
				["IsAxe"] = -1000000,
				["Ap"] = 1,
			},
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":ShamanRestoration"] = {
			["PerCharacterOptions"] = {
				["Nzeer-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							118.810623556582, -- [1]
							67123, -- [2]
						},
						["INVTYPE_FEET"] = {
							62.07235394769005, -- [1]
							61467, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							64.37888046932291, -- [1]
							56109, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							67.87990762124711, -- [1]
							62377, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							338.7759815242495, -- [1]
							56116, -- [2]
						},
						["INVTYPE_LEGS"] = {
							104.1293082375947, -- [1]
							66899, -- [2]
						},
						["INVTYPE_FINGER"] = {
							70.61207528721585, -- [1]
							55859, -- [2]
							67.87990762124711, -- [3]
							62436, -- [4]
						},
						["INVTYPE_RELIC"] = {
							37.82448036951501, -- [1]
							62241, -- [2]
						},
						["INVTYPE_WRIST"] = {
							52.54272517321017, -- [1]
							55566, -- [2]
						},
						["INVTYPE_WAIST"] = {
							72.50115473441107, -- [1]
							65836, -- [2]
						},
						["INVTYPE_NECK"] = {
							58.87297921478061, -- [1]
							56110, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							92.55427251732101, -- [1]
							66938, -- [2]
						},
						["INVTYPE_HAND"] = {
							91.635103926097, -- [1]
							63806, -- [2]
						},
						["INVTYPE_CHEST"] = {
							121.2678983833718, -- [1]
							56504, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Shaman: restoration",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "526fbf",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":MageFire"] = {
			["PerCharacterOptions"] = {
				["Pantyraid-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							165.9059520742077, -- [1]
							57864, -- [2]
						},
						["INVTYPE_FEET"] = {
							79.86034527183716, -- [1]
							66937, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							69.45941767585674, -- [1]
							57923, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							227.6660654470497, -- [1]
							56116, -- [2]
						},
						["INVTYPE_RANGED"] = {
							23.22545735635145, -- [1]
							55823, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							53.79129090440608, -- [1]
							62377, -- [2]
						},
						["INVTYPE_FINGER"] = {
							67.70729193506828, -- [1]
							56432, -- [2]
							61.24503993816027, -- [3]
							56432, -- [4]
						},
						["INVTYPE_LEGS"] = {
							132.6704457614017, -- [1]
							56413, -- [2]
						},
						["INVTYPE_HAND"] = {
							97.12367946405564, -- [1]
							58158, -- [2]
						},
						["INVTYPE_WAIST"] = {
							79.63617624323628, -- [1]
							63921, -- [2]
						},
						["INVTYPE_NECK"] = {
							75.83148673022416, -- [1]
							52322, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							79.72635918577686, -- [1]
							66910, -- [2]
						},
						["INVTYPE_WRIST"] = {
							52.22236536975007, -- [1]
							63826, -- [2]
						},
						["INVTYPE_CHEST"] = {
							132.6704457614017, -- [1]
							62441, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f03e00",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Mage: fire",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "b32e00",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":WarriorFury"] = {
			["PerCharacterOptions"] = {
				["Blendtech-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							100.6868163500288, -- [1]
							55229, -- [2]
						},
						["INVTYPE_FEET"] = {
							62.80944156591825, -- [1]
							49906, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							21.76818269046248, -- [1]
							55347, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							37.67184801381692, -- [1]
							55311, -- [2]
						},
						["INVTYPE_RANGED"] = {
							16.50546919976972, -- [1]
							55782, -- [2]
						},
						["INVTYPE_HAND"] = {
							59.45461523699866, -- [1]
							55026, -- [2]
						},
						["INVTYPE_FINGER"] = {
							40.43830358856265, -- [1]
							52310, -- [2]
							40.43830358856265, -- [3]
							52310, -- [4]
						},
						["INVTYPE_LEGS"] = {
							87.81404720782959, -- [1]
							55260, -- [2]
						},
						["INVTYPE_WRIST"] = {
							39.50259067357513, -- [1]
							55025, -- [2]
						},
						["INVTYPE_WAIST"] = {
							62.95682210708118, -- [1]
							55554, -- [2]
						},
						["INVTYPE_NECK"] = {
							37.91671464210324, -- [1]
							52312, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							67.73172135866436, -- [1]
							50020, -- [2]
						},
						["INVTYPE_CHEST"] = {
							98.2836307810401, -- [1]
							55500, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							22.72462099405104, -- [1]
							67029, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Warrior: fury",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "957552",
			["SmartGemSocketing"] = true,
		},
		["(Com) 85 PVE OH Com MAEP"] = {
			["Values"] = {
				["SpeedBaseline"] = 1.5,
				["CritRating"] = 0.47,
				["Agility"] = 1,
				["ResilienceRating"] = 0.001,
				["MeleeMaxDamage"] = 0,
				["HasteRating"] = 0.5600000000000001,
				["MasteryRating"] = 0.33,
				["YellowSocket"] = 31.2,
				["MeleeDps"] = 1.3,
				["ExpertiseRating"] = 0.59,
				["Strength"] = 0.41,
				["MetaSocket"] = 25.38,
				["RedSocket"] = 40,
				["BlueSocket"] = 30.4,
				["HitRating"] = 0.52,
				["MeleeSpeed"] = -650,
				["Stamina"] = 0.01,
				["MeleeMinDamage"] = 0,
				["Ap"] = 0.37,
			},
			["SmartGemSocketing"] = true,
			["PerCharacterOptions"] = {
				["Slashwin-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WRIST"] = {
							230.17, -- [1]
							63898, -- [2]
						},
						["INVTYPE_HEAD"] = {
							434.76, -- [1]
							66936, -- [2]
						},
						["INVTYPE_FEET"] = {
							284.82, -- [1]
							66967, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							476.5911111111112, -- [1]
							56127, -- [2]
						},
						["INVTYPE_CHEST"] = {
							402.73, -- [1]
							63866, -- [2]
						},
						["INVTYPE_RANGED"] = {
							109.51, -- [1]
							61401, -- [2]
						},
						["INVTYPE_FINGER"] = {
							235.47, -- [1]
							52316, -- [2]
							231.31, -- [3]
							52316, -- [4]
						},
						["INVTYPE_SHOULDER"] = {
							254.76, -- [1]
							55693, -- [2]
						},
						["INVTYPE_HAND"] = {
							298.77, -- [1]
							56484, -- [2]
						},
						["INVTYPE_WAIST"] = {
							345.33, -- [1]
							56098, -- [2]
						},
						["INVTYPE_NECK"] = {
							204.82, -- [1]
							65811, -- [2]
						},
						["INVTYPE_LEGS"] = {
							471.43, -- [1]
							56513, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							691.3514285714286, -- [1]
							66968, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							243.4, -- [1]
							56518, -- [2]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["SmartMetaGemSocketing"] = true,
			["MetaGemQualityLevel"] = 86,
		},
		["\"Wowhead\":WarlockDemonology"] = {
			["PerCharacterOptions"] = {
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Warlock: demonology",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "8d7bbf",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":PriestShadow"] = {
			["PerCharacterOptions"] = {
				["Zebsaru-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							85.99190793022837, -- [1]
							54485, -- [2]
						},
						["INVTYPE_FEET"] = {
							38.13324941557274, -- [1]
							54482, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							39.14116166157166, -- [1]
							65802, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							209.5750764251034, -- [1]
							55045, -- [2]
						},
						["INVTYPE_RANGED"] = {
							19.5491818018342, -- [1]
							67104, -- [2]
						},
						["INVTYPE_HAND"] = {
							58.13181082539111, -- [1]
							55737, -- [2]
						},
						["INVTYPE_FINGER"] = {
							40.40837978780795, -- [1]
							66893, -- [2]
							39.10519690703111, -- [3]
							56220, -- [4]
						},
						["INVTYPE_LEGS"] = {
							96.93957921237187, -- [1]
							56218, -- [2]
						},
						["INVTYPE_WRIST"] = {
							35.14188095666247, -- [1]
							55709, -- [2]
						},
						["INVTYPE_WAIST"] = {
							46.85470239165618, -- [1]
							55772, -- [2]
						},
						["INVTYPE_NECK"] = {
							43.71282143499371, -- [1]
							52314, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							58.51051969070311, -- [1]
							54479, -- [2]
						},
						["INVTYPE_CHEST"] = {
							78.54990109692501, -- [1]
							67106, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							43.85128573997483, -- [1]
							66889, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Priest: shadow",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfbfbf",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":DruidRestoration"] = {
			["PerCharacterOptions"] = {
				["Ravenstride-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							38.36340914771307, -- [1]
							56505, -- [2]
						},
						["INVTYPE_FEET"] = {
							2.889527618095476, -- [1]
							55656, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							19.05123719070232, -- [1]
							56518, -- [2]
						},
						["INVTYPE_HAND"] = {
							44.40489877530617, -- [1]
							56484, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							26.96550862284429, -- [1]
							56495, -- [2]
						},
						["INVTYPE_FINGER"] = {
							25.77230692326918, -- [1]
							61474, -- [2]
							20.29342664333916, -- [3]
							52308, -- [4]
						},
						["INVTYPE_WAIST"] = {
							42.80304923769057, -- [1]
							65801, -- [2]
						},
						["INVTYPE_WRIST"] = {
							29.50612346913271, -- [1]
							65798, -- [2]
						},
						["INVTYPE_RELIC"] = {
							25.51962009497625, -- [1]
							47670, -- [2]
						},
						["INVTYPE_NECK"] = {
							23.62934266433392, -- [1]
							55833, -- [2]
						},
						["INVTYPE_LEGS"] = {
							49.48287928017995, -- [1]
							56513, -- [2]
						},
						["INVTYPE_2HWEAPON"] = {
							60.1232191952012, -- [1]
							55246, -- [2]
						},
						["INVTYPE_CHEST"] = {
							36.41714571357161, -- [1]
							55646, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Druid: restoration",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf5d07",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":PriestHoly"] = {
			["PerCharacterOptions"] = {
				["Zebsaru-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							123.0965438446158, -- [1]
							54485, -- [2]
						},
						["INVTYPE_FEET"] = {
							47.95458440445587, -- [1]
							54482, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							29.96115395601257, -- [1]
							65802, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							249.1051128249071, -- [1]
							55045, -- [2]
						},
						["INVTYPE_RANGED"] = {
							21.966009711511, -- [1]
							67104, -- [2]
						},
						["INVTYPE_HAND"] = {
							75.135961153956, -- [1]
							55737, -- [2]
						},
						["INVTYPE_FINGER"] = {
							49.13853184804341, -- [1]
							56220, -- [2]
							49.13853184804341, -- [3]
							56220, -- [4]
						},
						["INVTYPE_LEGS"] = {
							124.2162239360183, -- [1]
							56218, -- [2]
						},
						["INVTYPE_WRIST"] = {
							29.45272779205941, -- [1]
							55709, -- [2]
						},
						["INVTYPE_WAIST"] = {
							39.36560982576406, -- [1]
							55772, -- [2]
						},
						["INVTYPE_NECK"] = {
							61.68151956583833, -- [1]
							52314, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							65.70037132247929, -- [1]
							54479, -- [2]
						},
						["INVTYPE_CHEST"] = {
							100.5272779205941, -- [1]
							67106, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							55.64038846043987, -- [1]
							66889, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Priest: holy",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfbfbf",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":HunterMarksman"] = {
			["PerCharacterOptions"] = {
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Hunter: marksman",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "809f56",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":DeathKnightBloodTank"] = {
			["PerCharacterOptions"] = {
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "DK: blood",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf3950",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":ShamanElemental"] = {
			["PerCharacterOptions"] = {
				["Nzeer-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							88.85894206549118, -- [1]
							67123, -- [2]
						},
						["INVTYPE_FEET"] = {
							42.97577988761867, -- [1]
							61467, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							62.78860685913583, -- [1]
							62234, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							56.11780662662275, -- [1]
							62377, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							215.6117031583027, -- [1]
							56116, -- [2]
						},
						["INVTYPE_LEGS"] = {
							84.42995543499322, -- [1]
							66899, -- [2]
						},
						["INVTYPE_FINGER"] = {
							56.11780662662275, -- [1]
							62436, -- [2]
							54.95524123231932, -- [3]
							55869, -- [4]
						},
						["INVTYPE_RELIC"] = {
							32.1387328037202, -- [1]
							62241, -- [2]
						},
						["INVTYPE_WRIST"] = {
							43.35865142414261, -- [1]
							55566, -- [2]
						},
						["INVTYPE_WAIST"] = {
							53.94400310017439, -- [1]
							65836, -- [2]
						},
						["INVTYPE_NECK"] = {
							49.14241426080217, -- [1]
							56110, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							65.04514628947878, -- [1]
							66938, -- [2]
						},
						["INVTYPE_HAND"] = {
							61.2371633404379, -- [1]
							55594, -- [2]
						},
						["INVTYPE_CHEST"] = {
							100.0970742104243, -- [1]
							56504, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Shaman: elemental",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "526fbf",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":PaladinRetribution"] = {
			["PerCharacterOptions"] = {
				["Brewn-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							24.11830194568723, -- [1]
							55039, -- [2]
						},
						["INVTYPE_FEET"] = {
							24.38216626781813, -- [1]
							56387, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							13.96857767141817, -- [1]
							56402, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							78.39068591748426, -- [1]
							55367, -- [2]
						},
						["INVTYPE_WRIST"] = {
							2.454999479762772, -- [1]
							63865, -- [2]
						},
						["INVTYPE_LEGS"] = {
							6.947560087399855, -- [1]
							55038, -- [2]
						},
						["INVTYPE_FINGER"] = {
							23.33284777858704, -- [1]
							62427, -- [2]
							6.2106960774113, -- [3]
							55799, -- [4]
						},
						["INVTYPE_RELIC"] = {
							7.700551451461866, -- [1]
							63772, -- [2]
						},
						["INVTYPE_HAND"] = {
							3.772760378732702, -- [1]
							63859, -- [2]
						},
						["INVTYPE_WAIST"] = {
							11.16408282176673, -- [1]
							63805, -- [2]
						},
						["INVTYPE_NECK"] = {
							7.306627822286963, -- [1]
							55864, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							4.858807616273021, -- [1]
							66907, -- [2]
						},
						["INVTYPE_CHEST"] = {
							23.01550306939965, -- [1]
							63919, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							10.42805119134325, -- [1]
							62377, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Paladin: retribution",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "b7698b",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":MageArcane"] = {
			["PerCharacterOptions"] = {
				["Pantyraid-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							161.5035971223022, -- [1]
							57864, -- [2]
						},
						["INVTYPE_FEET"] = {
							77.32771024559662, -- [1]
							66937, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							68.29372364177623, -- [1]
							57923, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							230.7670553212602, -- [1]
							56116, -- [2]
						},
						["INVTYPE_RANGED"] = {
							22.58447035475068, -- [1]
							55823, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							54.98238650458943, -- [1]
							62377, -- [2]
						},
						["INVTYPE_FINGER"] = {
							65.42594889605556, -- [1]
							56432, -- [2]
							58.54924336392954, -- [3]
							56432, -- [4]
						},
						["INVTYPE_LEGS"] = {
							128.2842967005706, -- [1]
							56413, -- [2]
						},
						["INVTYPE_HAND"] = {
							95.33291987099975, -- [1]
							58158, -- [2]
						},
						["INVTYPE_WAIST"] = {
							77.24584470354751, -- [1]
							63921, -- [2]
						},
						["INVTYPE_NECK"] = {
							74.20788886132473, -- [1]
							52322, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							78.45398164227238, -- [1]
							66910, -- [2]
						},
						["INVTYPE_WRIST"] = {
							51.3855122798313, -- [1]
							63826, -- [2]
						},
						["INVTYPE_CHEST"] = {
							128.2842967005706, -- [1]
							62441, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Mage: arcane",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "4e99b3",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":RogueAssassination"] = {
			["PerCharacterOptions"] = {
				["Yiffylube-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONOFFHAND"] = {
							2.224873134893585, -- [1]
							44096, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							0.9865939559191093, -- [1]
							42952, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							2.538838575648391, -- [1]
							42945, -- [2]
						},
						["INVTYPE_CHEST"] = {
							1.13951374687571, -- [1]
							48689, -- [2]
						},
					},
				},
				["Slashwin-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONMAINHAND"] = {
							124.0785680022217, -- [1]
							56127, -- [2]
						},
						["INVTYPE_HEAD"] = {
							126.9554646671211, -- [1]
							66936, -- [2]
						},
						["INVTYPE_FEET"] = {
							65.48170870256759, -- [1]
							66967, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							118.967442464375, -- [1]
							66968, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							59.89638718473074, -- [1]
							56518, -- [2]
						},
						["INVTYPE_RANGED"] = {
							24.84821631447398, -- [1]
							61401, -- [2]
						},
						["INVTYPE_FINGER"] = {
							53.95296523517382, -- [1]
							52316, -- [2]
							53.18950238582141, -- [3]
							52316, -- [4]
						},
						["INVTYPE_LEGS"] = {
							106.1351965462395, -- [1]
							56513, -- [2]
						},
						["INVTYPE_WRIST"] = {
							48.52874346739377, -- [1]
							63898, -- [2]
						},
						["INVTYPE_WAIST"] = {
							73.61690524880709, -- [1]
							56098, -- [2]
						},
						["INVTYPE_NECK"] = {
							47.16518972960691, -- [1]
							65811, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							61.90752101795047, -- [1]
							55693, -- [2]
						},
						["INVTYPE_HAND"] = {
							67.26289479663713, -- [1]
							56484, -- [2]
						},
						["INVTYPE_CHEST"] = {
							85.80527152919791, -- [1]
							63866, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["LocalizedName"] = "Rogue: assassination",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfb74e",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":WarriorTank"] = {
			["PerCharacterOptions"] = {
				["Blendtech-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							137.6860465116279, -- [1]
							55229, -- [2]
						},
						["INVTYPE_FEET"] = {
							89.95348837209302, -- [1]
							49906, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							29.93798449612403, -- [1]
							55347, -- [2]
						},
						["INVTYPE_CHEST"] = {
							125.6356589147287, -- [1]
							55500, -- [2]
						},
						["INVTYPE_RANGED"] = {
							29.48643410852713, -- [1]
							55782, -- [2]
						},
						["INVTYPE_HAND"] = {
							86.87596899224806, -- [1]
							55026, -- [2]
						},
						["INVTYPE_FINGER"] = {
							57.06007751937985, -- [1]
							52310, -- [2]
							57.06007751937985, -- [3]
							52310, -- [4]
						},
						["INVTYPE_SHOULDER"] = {
							93.17441860465117, -- [1]
							50020, -- [2]
						},
						["INVTYPE_WRIST"] = {
							53.73643410852714, -- [1]
							47572, -- [2]
						},
						["INVTYPE_WAIST"] = {
							86.00387596899225, -- [1]
							55554, -- [2]
						},
						["INVTYPE_NECK"] = {
							46.02519379844961, -- [1]
							52312, -- [2]
						},
						["INVTYPE_LEGS"] = {
							114.7519379844961, -- [1]
							55260, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							56.89341085271318, -- [1]
							55311, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							35.91860465116279, -- [1]
							67029, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["LocalizedName"] = "Warrior: tank",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "957552",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":DruidFeralDps"] = {
			["PerCharacterOptions"] = {
				["Ravenstride-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							82.30895196506549, -- [1]
							56505, -- [2]
						},
						["INVTYPE_FEET"] = {
							51.15038209606986, -- [1]
							55656, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							55.01871490954461, -- [1]
							56518, -- [2]
						},
						["INVTYPE_HAND"] = {
							62.73471615720524, -- [1]
							56484, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							57.81522925764192, -- [1]
							56495, -- [2]
						},
						["INVTYPE_FINGER"] = {
							51.62098409232689, -- [1]
							61474, -- [2]
							43.33944167186525, -- [3]
							52308, -- [4]
						},
						["INVTYPE_WAIST"] = {
							61.36833281347473, -- [1]
							65801, -- [2]
						},
						["INVTYPE_WRIST"] = {
							43.08990954460387, -- [1]
							65798, -- [2]
						},
						["INVTYPE_RELIC"] = {
							31.21257018091079, -- [1]
							62242, -- [2]
						},
						["INVTYPE_NECK"] = {
							45.52811135371179, -- [1]
							55833, -- [2]
						},
						["INVTYPE_LEGS"] = {
							105.9148861509669, -- [1]
							56513, -- [2]
						},
						["INVTYPE_2HWEAPON"] = {
							87.30418411906247, -- [1]
							55246, -- [2]
						},
						["INVTYPE_CHEST"] = {
							78.04604647535869, -- [1]
							55646, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Druid: feral cat",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf5d07",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":DruidBalance"] = {
			["PerCharacterOptions"] = {
				["Ravenstride-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							37.35626535626535, -- [1]
							56505, -- [2]
						},
						["INVTYPE_FEET"] = {
							27.88149688149688, -- [1]
							55656, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							35.95237195237196, -- [1]
							56518, -- [2]
						},
						["INVTYPE_HAND"] = {
							32.93781893781894, -- [1]
							56484, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							26.25760725760726, -- [1]
							56495, -- [2]
						},
						["INVTYPE_FINGER"] = {
							23.84331884331884, -- [1]
							61474, -- [2]
							19.76072576072576, -- [3]
							52308, -- [4]
						},
						["INVTYPE_WAIST"] = {
							31.83991683991684, -- [1]
							65801, -- [2]
						},
						["INVTYPE_WRIST"] = {
							21.7962577962578, -- [1]
							65798, -- [2]
						},
						["INVTYPE_RELIC"] = {
							18.06917406917407, -- [1]
							47670, -- [2]
						},
						["INVTYPE_NECK"] = {
							23.62502362502362, -- [1]
							55401, -- [2]
						},
						["INVTYPE_LEGS"] = {
							48.18389718389718, -- [1]
							56513, -- [2]
						},
						["INVTYPE_2HWEAPON"] = {
							44.5970515970516, -- [1]
							55246, -- [2]
						},
						["INVTYPE_CHEST"] = {
							35.46116046116046, -- [1]
							55646, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Druid: balance",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf5d07",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":DruidFeralTank"] = {
			["PerCharacterOptions"] = {
				["Ravenstride-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							176.9530086856462, -- [1]
							56505, -- [2]
						},
						["INVTYPE_FEET"] = {
							110.4454863406732, -- [1]
							55656, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							115.9061889645357, -- [1]
							56518, -- [2]
						},
						["INVTYPE_HAND"] = {
							143.8733641864714, -- [1]
							56484, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							130.4260054607026, -- [1]
							56495, -- [2]
						},
						["INVTYPE_FINGER"] = {
							94.22740142220518, -- [1]
							61474, -- [2]
							77.51724764437805, -- [3]
							52308, -- [4]
						},
						["INVTYPE_WAIST"] = {
							139.4195101517591, -- [1]
							65801, -- [2]
						},
						["INVTYPE_WRIST"] = {
							99.78904124798757, -- [1]
							65798, -- [2]
						},
						["INVTYPE_RELIC"] = {
							52.87090636560464, -- [1]
							62242, -- [2]
						},
						["INVTYPE_NECK"] = {
							61.44552166869382, -- [1]
							55833, -- [2]
						},
						["INVTYPE_LEGS"] = {
							223.2453329161262, -- [1]
							56513, -- [2]
						},
						["INVTYPE_2HWEAPON"] = {
							163.5420515197898, -- [1]
							55246, -- [2]
						},
						["INVTYPE_CHEST"] = {
							175.4742786775208, -- [1]
							55646, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Druid: feral bear",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf5d07",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":HunterSurvival"] = {
			["PerCharacterOptions"] = {
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["LocalizedName"] = "Hunter: survival",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "809f56",
			["SmartGemSocketing"] = true,
		},
		["\"Wowhead\":RogueSubtlety"] = {
			["PerCharacterOptions"] = {
				["Yiffylube-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONOFFHAND"] = {
							2.711621896058341, -- [1]
							44096, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							1.052893935198006, -- [1]
							42952, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							3.083198164339122, -- [1]
							42945, -- [2]
						},
						["INVTYPE_CHEST"] = {
							1.16449736914982, -- [1]
							48689, -- [2]
						},
					},
				},
				["Slashwin-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONMAINHAND"] = {
							137.6061241444792, -- [1]
							66968, -- [2]
						},
						["INVTYPE_HEAD"] = {
							142.0163389642758, -- [1]
							66936, -- [2]
						},
						["INVTYPE_FEET"] = {
							67.4785378011631, -- [1]
							66967, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							146.5770639096587, -- [1]
							56127, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							59.57463306563279, -- [1]
							56518, -- [2]
						},
						["INVTYPE_RANGED"] = {
							26.4849072279147, -- [1]
							61401, -- [2]
						},
						["INVTYPE_FINGER"] = {
							56.96122957629465, -- [1]
							52316, -- [2]
							54.79008584879535, -- [3]
							52316, -- [4]
						},
						["INVTYPE_LEGS"] = {
							110.822763777347, -- [1]
							56513, -- [2]
						},
						["INVTYPE_WRIST"] = {
							53.28856272500692, -- [1]
							63898, -- [2]
						},
						["INVTYPE_WAIST"] = {
							81.55857103295486, -- [1]
							56098, -- [2]
						},
						["INVTYPE_NECK"] = {
							48.5859872611465, -- [1]
							65811, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							63.26363888119634, -- [1]
							55693, -- [2]
						},
						["INVTYPE_HAND"] = {
							70.21434505677097, -- [1]
							56484, -- [2]
						},
						["INVTYPE_CHEST"] = {
							95.19219052893935, -- [1]
							63866, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["LocalizedName"] = "Rogue: subtlety",
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfb74e",
			["SmartGemSocketing"] = true,
		},
		["(Com) 85 PVE MH Com MAEP"] = {
			["Values"] = {
				["SpeedBaseline"] = 2.5,
				["CritRating"] = 0.47,
				["Agility"] = 1,
				["ResilienceRating"] = 0.001,
				["MeleeMaxDamage"] = 0,
				["HasteRating"] = 0.5600000000000001,
				["MasteryRating"] = 0.33,
				["YellowSocket"] = 31.2,
				["MeleeDps"] = 2.85,
				["ExpertiseRating"] = 0.59,
				["Strength"] = 0.41,
				["MetaSocket"] = 25.38,
				["RedSocket"] = 40,
				["BlueSocket"] = 30.4,
				["HitRating"] = 0.52,
				["MeleeSpeed"] = 200,
				["Stamina"] = 0.01,
				["MeleeMinDamage"] = 0,
				["Ap"] = 0.37,
			},
			["SmartGemSocketing"] = true,
			["PerCharacterOptions"] = {
				["Slashwin-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONMAINHAND"] = {
							1093.896666666667, -- [1]
							56127, -- [2]
						},
						["INVTYPE_HEAD"] = {
							434.76, -- [1]
							66936, -- [2]
						},
						["INVTYPE_FEET"] = {
							284.82, -- [1]
							66967, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							928.369285714286, -- [1]
							66968, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							243.4, -- [1]
							56518, -- [2]
						},
						["INVTYPE_RANGED"] = {
							109.51, -- [1]
							61401, -- [2]
						},
						["INVTYPE_FINGER"] = {
							235.47, -- [1]
							52316, -- [2]
							231.31, -- [3]
							52316, -- [4]
						},
						["INVTYPE_LEGS"] = {
							471.43, -- [1]
							56513, -- [2]
						},
						["INVTYPE_HAND"] = {
							298.77, -- [1]
							56484, -- [2]
						},
						["INVTYPE_WAIST"] = {
							345.33, -- [1]
							56098, -- [2]
						},
						["INVTYPE_NECK"] = {
							204.82, -- [1]
							65811, -- [2]
						},
						["INVTYPE_SHOULDER"] = {
							254.76, -- [1]
							55693, -- [2]
						},
						["INVTYPE_WRIST"] = {
							230.17, -- [1]
							63898, -- [2]
						},
						["INVTYPE_CHEST"] = {
							402.73, -- [1]
							63866, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "5bbcff",
			["UnenchantedColor"] = "448dbf",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
		},
		["(Ass) 85 PVE OH Mut MAEP"] = {
			["Values"] = {
				["SpeedBaseline"] = 1.4,
				["CritRating"] = 0.43,
				["Agility"] = 1,
				["ResilienceRating"] = 0.001,
				["MeleeMaxDamage"] = 0,
				["HasteRating"] = 0.46,
				["MasteryRating"] = 0.49,
				["YellowSocket"] = 29.8,
				["MeleeDps"] = 1.3,
				["ExpertiseRating"] = 0.42,
				["Strength"] = 0.42,
				["MetaSocket"] = 26.46,
				["RedSocket"] = 40,
				["BlueSocket"] = 30.6,
				["HitRating"] = 0.53,
				["MeleeSpeed"] = -500,
				["Stamina"] = 0.01,
				["MeleeMinDamage"] = 0,
				["Ap"] = 0.38,
			},
			["SmartGemSocketing"] = true,
			["PerCharacterOptions"] = {
				["Slashwin-Caelestrasz"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WRIST"] = {
							210.85, -- [1]
							63898, -- [2]
						},
						["INVTYPE_HEAD"] = {
							416.6999999999999, -- [1]
							66936, -- [2]
						},
						["INVTYPE_FEET"] = {
							283.05, -- [1]
							66967, -- [2]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							456.2311111111111, -- [1]
							56127, -- [2]
						},
						["INVTYPE_CHEST"] = {
							379.63, -- [1]
							63866, -- [2]
						},
						["INVTYPE_RANGED"] = {
							106.97, -- [1]
							61401, -- [2]
						},
						["INVTYPE_FINGER"] = {
							230.55, -- [1]
							52316, -- [2]
							229.99, -- [3]
							52316, -- [4]
						},
						["INVTYPE_SHOULDER"] = {
							251.84, -- [1]
							55693, -- [2]
						},
						["INVTYPE_HAND"] = {
							282.04, -- [1]
							56484, -- [2]
						},
						["INVTYPE_WAIST"] = {
							325.65, -- [1]
							56098, -- [2]
						},
						["INVTYPE_NECK"] = {
							204.05, -- [1]
							65811, -- [2]
						},
						["INVTYPE_LEGS"] = {
							445.08, -- [1]
							56513, -- [2]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							615.8314285714287, -- [1]
							66968, -- [2]
						},
						["INVTYPE_CLOAK"] = {
							248.9, -- [1]
							56518, -- [2]
						},
					},
				},
			},
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f0ff00",
			["UnenchantedColor"] = "b3bf00",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 86,
		},
	},
	["ShowItemID"] = false,
	["ShowAsterisks"] = 0,
	["ShowUpgradeAdvisors"] = true,
	["ButtonPosition"] = 2,
	["ShowUpgradesOnTooltips"] = true,
	["ShowValuesForUpgradesOnly"] = true,
	["ShowUnenchanted"] = true,
	["Debug"] = false,
}
