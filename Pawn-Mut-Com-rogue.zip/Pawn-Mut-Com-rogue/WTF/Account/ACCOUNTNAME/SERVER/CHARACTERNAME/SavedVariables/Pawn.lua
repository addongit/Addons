
PawnOptions = {
	["LastPlayerFullName"] = "Slashwin-Caelestrasz",
	["LastKeybindingsSet"] = 1,
}
PawnWowheadScaleProviderOptions = {
	["LastAdded"] = 2,
}
